

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QApplication
from PyQt5.QtGui import QIcon
from DataBaseOperation import DBOperation


class ForgotPasswordWindow(QWidget):
    def __init__(self, username):
        super().__init__()
        self.username  =  username

        self.setWindowTitle("Reset Password")
        self.setWindowIcon(QIcon(""))
        self.resize(400, 200)
        
        layout = QVBoxLayout()

        self.label_new_password = QLabel("New Password:")
        self.input_new_password = QLineEdit()
        self.input_new_password.setEchoMode(QLineEdit.Password)

        self.label_confirm_password = QLabel("Confirm Password:")
        self.input_confirm_password = QLineEdit()
        self.input_confirm_password.setEchoMode(QLineEdit.Password)

        self.btn_submit = QPushButton("Submit")
        self.btn_submit.clicked.connect(self.submit_new_password)

        self.error_msg = QLabel()
        self.error_msg.setStyleSheet("color:red;")

        layout.addWidget(self.label_new_password)
        layout.addWidget(self.input_new_password)
        layout.addWidget(self.label_confirm_password)
        layout.addWidget(self.input_confirm_password)
        layout.addWidget(self.btn_submit)
        layout.addWidget(self.error_msg)

        self.setLayout(layout)

    def submit_new_password(self):
        new_password = self.input_new_password.text()
        confirm_password = self.input_confirm_password.text()

        if new_password == "" or confirm_password == "":
            self.error_msg.setText("Please fill in both fields.")
            return

        if new_password != confirm_password:
            self.error_msg.setText("Passwords do not match.")
            return

        # Update the password in the database
        dboperation = DBOperation(host="localhost",user="root",passwd="python",database="test")
        success = dboperation.updatePassword(self.username,new_password)  

        if success:
            self.error_msg.setText("Password updated successfully!")
            self.close()
            self.open_login_screen()
        else:
            self.error_msg.setText("Failed to update password.")

    def open_login_screen(self):
        from LoginWindow import LoginScreen
        self.login_screen = LoginScreen()
        self.login_screen.show()
        self.close()